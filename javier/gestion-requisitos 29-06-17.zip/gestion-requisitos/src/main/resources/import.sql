-- Dumping data for table `gestion_requisito`

INSERT INTO `gestion_requisito` (`id`, `nombre`) VALUES (1,'Sistema Requisitos 2017');


--
-- Dumping data for table `proyecto`
--

/*!40000 ALTER TABLE `proyecto` DISABLE KEYS */;
INSERT INTO `proyecto` (`id`, `descripcion_proyecto`, `nombre_proyecto`, `version`, `aplicacion_id`) VALUES (1,'Cambio de version de BBDD','Proyecto 1', 0,1);
INSERT INTO `proyecto` (`id`, `descripcion_proyecto`, `nombre_proyecto`, `version`, `aplicacion_id`) VALUES (2,'Proyecto Semaforos','Proyecto 2', 0,1);
INSERT INTO `proyecto` (`id`, `descripcion_proyecto`, `nombre_proyecto`, `version`, `aplicacion_id`) VALUES (3,'Sistema Contable','Proyecto 3', 0,1);
INSERT INTO `proyecto` (`id`, `descripcion_proyecto`, `nombre_proyecto`, `version`, `aplicacion_id`) VALUES (4,'Cambio de version de BBDD','Proyecto 4', 0,1);