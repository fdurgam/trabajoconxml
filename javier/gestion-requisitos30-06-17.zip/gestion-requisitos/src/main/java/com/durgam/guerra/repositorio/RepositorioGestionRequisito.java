package com.durgam.guerra.repositorio;
import org.springframework.data.jpa.repository.JpaRepository;
import com.durgam.guerra.dominio.GestionRequisito;
public interface RepositorioGestionRequisito extends JpaRepository<GestionRequisito, Long>  {

}
