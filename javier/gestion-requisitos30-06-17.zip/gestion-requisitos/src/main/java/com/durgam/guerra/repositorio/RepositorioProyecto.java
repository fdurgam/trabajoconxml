package com.durgam.guerra.repositorio;


import javax.persistence.LockModeType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;

import com.durgam.guerra.dominio.Proyecto;
public interface RepositorioProyecto extends JpaRepository<Proyecto, Long> {
	

}
