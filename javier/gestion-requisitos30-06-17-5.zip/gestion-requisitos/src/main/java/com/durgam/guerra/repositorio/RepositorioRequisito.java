package com.durgam.guerra.repositorio;
import org.springframework.data.jpa.repository.JpaRepository;
import com.durgam.guerra.dominio.Requisito;
public interface RepositorioRequisito extends JpaRepository<Requisito, Long> {

}
