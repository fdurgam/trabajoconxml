package com.durgam.guerra;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import com.durgam.guerra.dominio.GestionRequisito;
import com.durgam.guerra.servicio.ServicioGestionRequisito;

@SpringBootApplication
public class GestionRequisitosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionRequisitosApplication.class, args);
	
//		GestionRequisito app = GestionRequisito.getSistema();
//		System.out.println(app.getNombre());
		
//		ServicioGestionRequisito servicioGestionRequisito = new ServicioGestionRequisito();
//		
//		GestionRequisito app = (servicioGestionRequisito.buscarGestionRequisitoPorId(1)).getSistema();
//		System.out.println(app.getNombre());
//		app.setNombre("App 2017");		
//		servicioGestionRequisito.GrabarGestionRequisito(app);
//		System.out.println(app.getNombre());

//		entityManager.getTransaction().begin();

//		entityManager.persist(app);	
		
		
//		entityManager.getTransaction().commit();
//		entitpublicyManager.close();
	    
      
        
	}
}
